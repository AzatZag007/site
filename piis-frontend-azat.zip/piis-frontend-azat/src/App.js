import {UsersTableWrapper} from "./features/users/containers/UsersTableWrapper/UsersTableWrapper";

import './App.css';

function App() {
  return (
    <div>
      <UsersTableWrapper />
    </div>
  );
}

export default App;
