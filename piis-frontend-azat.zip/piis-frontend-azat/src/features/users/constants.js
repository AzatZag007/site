export const rows = [
  {
    id: 1,
    name: "name",
    salary: "340000",
    birthdate: "13.07.2001",
  },
  {
    id: 2,
    name: "name",
    salary: "340000",
    birthdate: "13.07.2001",
  },
  {
    id: 3,
    name: "name",
    salary: "340000",
    birthdate: "13.07.2001",
  },
  {
    id: 4,
    name: "name",
    salary: "340000",
    birthdate: "13.07.2001",
  },
  {
    id: 5,
    name: "name",
    salary: "340000",
    birthdate: "13.07.2001",
  },
];
