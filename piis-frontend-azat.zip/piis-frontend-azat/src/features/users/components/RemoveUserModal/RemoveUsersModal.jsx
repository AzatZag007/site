import Button from "@mui/material/Button";
import WarningIcon from "@mui/icons-material/Warning";

import { CommonModal } from "../../../../ui/shared/Modal/Modal";

export const RemoveUserModal = ({ isOpen, onCancel, onApply }) => {
  return (
    <CommonModal
      isOpen={isOpen}
      title="Удаление пользователя"
      actions={
        <>
          <Button onClick={onCancel}>Нет</Button>
          <Button onClick={onApply}>Да</Button>
        </>
      }
    >
      <div style={{ display: "flex", alignItems: "center", gap: "1rem" }}>
        <WarningIcon color="warning" />
        <p>Вы действительно хотите удалить пользователя?</p>
      </div>
    </CommonModal>
  );
};
