import TextField from "@mui/material/TextField";

export const UserSalaryField = ({ onSetUser }) => {
  return (
    <TextField
      id="outlined-basic"
      label="Зарплата"
      variant="outlined"
      onChange={(e) =>
        onSetUser((prev) => {
          return {
            ...prev,
            salary: e.target.value,
          };
        })
      }
    />
  );
};
