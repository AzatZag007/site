import { UsersTable } from "../../components/UsersTable/UsersTable";
import "./UsersTableWrapper.css";

export const UsersTableWrapper = () => {
  return (
    <div className="users-table-wrapper">
      <h3>Список сотрудников</h3>
      <UsersTable />
    </div>
  );
};
